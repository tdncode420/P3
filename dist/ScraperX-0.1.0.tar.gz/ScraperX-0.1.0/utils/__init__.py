__author__ = 'Renegade'
__name__ = 'WebScraperX'
__version__ = "0.1.0"

